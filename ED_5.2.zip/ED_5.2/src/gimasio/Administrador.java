package gimasio;

public class Administrador extends Actor {
	public Administrador() {
	}
}
